import os
import asyncio
import traceback

import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv

from utils.database import init_database


# ============================================================
#                 S A V A G E • B O T
# ============================================================

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise RuntimeError(
        "❌ Токен бота не найден! Проверь файл .env"
    )


# ============================================================
#                     НАСТРОЙКИ
# ============================================================

GUILD_ID = 1427671482905006182
GUILD = discord.Object(id=GUILD_ID)


# ============================================================
#                       INTENTS
# ============================================================

intents = discord.Intents.default()

intents.guilds = True
intents.members = True
intents.message_content = True


# ============================================================
#                         BOT
# ============================================================

class SavageBot(commands.Bot):

    def __init__(self):

        super().__init__(
            command_prefix="!",
            intents=intents
        )

    # ========================================================
    #                     SETUP HOOK
    # ========================================================

    async def setup_hook(self):

        print()
        print("=" * 60)
        print("          ЗАГРУЗКА S A V A G E")
        print("=" * 60)

        # ----------------------------------------------------
        # GENERAL
        # ----------------------------------------------------

        try:

            await self.load_extension(
                "cogs.general"
            )

            print(
                "✅ general.py загружен"
            )

        except Exception as error:

            print(
                "❌ Ошибка загрузки general.py:"
            )

            print(
                f"{type(error).__name__}: {error}"
            )

            traceback.print_exc()

        # ----------------------------------------------------
        # TICKETS
        # ----------------------------------------------------

        try:

            await self.load_extension(
                "cogs.tickets"
            )

            print(
                "✅ tickets.py загружен"
            )

        except Exception as error:

            print(
                "❌ Ошибка загрузки tickets.py:"
            )

            print(
                f"{type(error).__name__}: {error}"
            )

            traceback.print_exc()

        # ====================================================
        # ПРОВЕРЯЕМ КОМАНДЫ
        # ====================================================

        print()
        print("🔎 Проверка команд...")

        commands_list = self.tree.get_commands()

        print(
            f"📦 Команд в дереве: "
            f"{len(commands_list)}"
        )

        for command in commands_list:

            print(
                f"   • /{command.name}"
            )

        # ====================================================
        # СИНХРОНИЗАЦИЯ
        # ====================================================

        print()
        print("🔄 Синхронизация команд с сервером...")

        try:

            # ------------------------------------------------
            # Копируем существующие команды
            # на конкретный сервер.
            #
            # Никаких clear_commands()
            # Никаких add_command()
            # ------------------------------------------------

            self.tree.copy_global_to(
                guild=GUILD
            )

            synced = await self.tree.sync(
                guild=GUILD
            )

            print()
            print(
                "✅ Slash-команды синхронизированы."
            )

            print(
                f"📊 Всего команд: {len(synced)}"
            )

            for command in synced:

                print(
                    f"   • /{command.name}"
                )

        except Exception as error:

            print()
            print(
                "❌ ОШИБКА СИНХРОНИЗАЦИИ КОМАНД:"
            )

            print(
                f"{type(error).__name__}: {error}"
            )

            traceback.print_exc()

        print()
        print("=" * 60)
        print("       S A V A G E • SETUP ЗАВЕРШЁН")
        print("=" * 60)
        print()


# ============================================================
#                    СОЗДАЁМ БОТА
# ============================================================

bot = SavageBot()


# ============================================================
#                    GLOBAL INTERACTION LOG
# ============================================================

@bot.event
async def on_interaction(
    interaction: discord.Interaction
):

    # --------------------------------------------------------
    # Логируем только application commands
    # и component interactions.
    # --------------------------------------------------------

    try:

        if interaction.type == discord.InteractionType.application_command:

            command_name = (
                interaction.data.get("name")
                if interaction.data
                else "unknown"
            )

            print(
                f"📥 INTERACTION COMMAND: "
                f"/{command_name} | "
                f"user={interaction.user} | "
                f"id={interaction.user.id}"
            )

        elif interaction.type == discord.InteractionType.component:

            custom_id = (
                interaction.data.get("custom_id")
                if interaction.data
                else "unknown"
            )

            print(
                f"🖱️ INTERACTION BUTTON: "
                f"{custom_id} | "
                f"user={interaction.user} | "
                f"id={interaction.user.id}"
            )

    except Exception as error:

        print(
            "⚠️ Ошибка логирования interaction:"
        )

        print(
            f"{type(error).__name__}: {error}"
        )

    # --------------------------------------------------------
    # ВАЖНО:
    #
    # НЕ вызываем здесь ничего вроде
    # interaction.response.send_message().
    #
    # on_interaction используется только для логирования.
    # --------------------------------------------------------


# ============================================================
#                 SLASH COMMAND ERROR
# ============================================================

@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError
):

    print()
    print("=" * 60)
    print("❌ ОШИБКА SLASH-КОМАНДЫ")
    print("=" * 60)

    print(
        f"Пользователь: {interaction.user}"
    )

    print(
        f"User ID: {interaction.user.id}"
    )

    print(
        f"Команда: "
        f"{interaction.command}"
    )

    print(
        f"Ошибка: "
        f"{type(error).__name__}: {error}"
    )

    traceback.print_exception(
        type(error),
        error,
        error.__traceback__
    )

    print("=" * 60)
    print()

    # --------------------------------------------------------
    # Если команда уже отправила response,
    # используем followup.
    # --------------------------------------------------------

    try:

        if interaction.response.is_done():

            await interaction.followup.send(
                "❌ При выполнении команды произошла ошибка.",
                ephemeral=True
            )

        else:

            await interaction.response.send_message(
                "❌ При выполнении команды произошла ошибка.",
                ephemeral=True
            )

    except Exception as send_error:

        print(
            "❌ Не удалось отправить сообщение "
            "об ошибке:"
        )

        print(
            f"{type(send_error).__name__}: "
            f"{send_error}"
        )


# ============================================================
#                         READY
# ============================================================

@bot.event
async def on_ready():

    print()
    print("=" * 60)
    print("                 S A V A G E")
    print("=" * 60)

    print(
        f"🤖 Бот: {bot.user}"
    )

    print(
        f"🆔 ID: {bot.user.id}"
    )

    print(
        f"🏠 Сервер ID: {GUILD_ID}"
    )

    print(
        f"🌐 Серверов: {len(bot.guilds)}"
    )

    guild = bot.get_guild(
        GUILD_ID
    )

    if guild:

        print(
            f"✅ Сервер найден: "
            f"{guild.name}"
        )

        print(
            f"👥 Участников: "
            f"{guild.member_count}"
        )

    else:

        print(
            "⚠️ Целевой сервер не найден "
            "в кеше бота."
        )

    # --------------------------------------------------------
    # Проверяем slash-команды
    # --------------------------------------------------------

    try:

        guild_commands = (
            await bot.tree.fetch_commands(
                guild=GUILD
            )
        )

        print()
        print(
            "📋 Команды Discord на сервере:"
        )

        for command in guild_commands:

            print(
                f"   • /{command.name}"
            )

        print(
            f"📊 Всего: "
            f"{len(guild_commands)}"
        )

    except Exception as error:

        print(
            "⚠️ Не удалось получить "
            "команды Discord:"
        )

        print(
            f"{type(error).__name__}: {error}"
        )

    print("=" * 60)
    print()


# ============================================================
#                     DISCONNECT
# ============================================================

@bot.event
async def on_disconnect():

    print()
    print(
        "⚠️ S A V A G E отключился от Discord."
    )
    print()


# ============================================================
#                     RESUMED
# ============================================================

@bot.event
async def on_resumed():

    print()
    print(
        "🔄 S A V A G E восстановил соединение."
    )
    print()


# ============================================================
#                     BOT ERROR
# ============================================================

@bot.event
async def on_error(
    event,
    *args,
    **kwargs
):

    print()
    print("=" * 60)
    print(
        f"❌ ГЛОБАЛЬНАЯ ОШИБКА СОБЫТИЯ: "
        f"{event}"
    )
    print("=" * 60)

    traceback.print_exc()

    print("=" * 60)
    print()


# ============================================================
#                         MAIN
# ============================================================

async def main():

    # --------------------------------------------------------
    # DATABASE
    # --------------------------------------------------------

    print(
        "🗄️ Инициализация базы данных..."
    )

    try:

        init_database()

        print(
            "✅ База данных готова."
        )

    except Exception as error:

        print(
            "❌ Ошибка базы данных:"
        )

        print(
            f"{type(error).__name__}: {error}"
        )

        traceback.print_exc()

        raise

    # --------------------------------------------------------
    # DISCORD
    # --------------------------------------------------------

    print(
        "🔌 Подключение к Discord..."
    )

    async with bot:

        await bot.start(
            TOKEN
        )


# ============================================================
#                         START
# ============================================================

if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )

    except KeyboardInterrupt:

        print()
        print(
            "🛑 S A V A G E BOT остановлен."
        )

    except Exception as error:

        print()
        print("=" * 60)
        print(
            "💥 КРИТИЧЕСКАЯ ОШИБКА"
        )
        print("=" * 60)

        print(
            f"{type(error).__name__}: "
            f"{error}"
        )

        traceback.print_exc()

        print("=" * 60)